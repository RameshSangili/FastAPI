
import { useEffect, useState } from "react";

function Chat() {

  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [conversationId, setConversationId] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("conversationId");
    if (saved) setConversationId(saved);
  }, []);

  async function sendMessage() {
    if (!input.trim()) return;
  
    const userMsg = input;
    setInput("");
  
    setMessages(m => [...m, { role: "user", text: userMsg }]);
    setLoading(true);
  
    const url = conversationId
      ? "http://127.0.0.1:8000/api/chat/continue"
      : "http://127.0.0.1:8000/api/chat/start";
  
    const body = {
      message: userMsg,
      conversationId: conversationId
    };
  
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
  
      const data = await res.json();
  
      console.log("FULL RESPONSE:", data);
  
      // ALWAYS update conversationId if backend sends it
      if (data.contextId) {
        setConversationId(data.contextId);
      }
  
      const assistantText =
  data?.result?.response ||
  data?.response ||
  data?.reply ||
  "No response received";

setMessages(m => [
  ...m,
  {
    role: "assistant",
    text: assistantText
  }
]);
      
  
    } catch (err) {
      console.error(err);
      setMessages(m => [
        ...m,
        { role: "assistant", text: "Server error." }
      ]);
    }
  
    setLoading(false);
  }

  return (
    <div className="chat-widget">

      <div className="chat-header">
        Loan Assistant
      </div>

      <div className="chat-body">
        {messages.map((m, i) => (
          <div key={i} className={`msg ${m.role}`}>
            {m.text}
          </div>
        ))}

        {loading && (
          <div className="msg assistant">
            Assistant is typing...
          </div>
        )}
      </div>

      <div className="chat-input-area">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Ask about loans..."
          onKeyDown={e => e.key === "Enter" && sendMessage()}
        />
        <button onClick={sendMessage}>➤</button>
      </div>

    </div>
  );
}

export default Chat;